.. role:: hidden
    :class: hidden-section

mmeval.utils
===================================

.. contents:: mmeval.utils
   :depth: 2
   :local:
   :backlinks: top

.. currentmodule:: mmeval.utils


misc
----------------

.. autosummary::
   :toctree: generated
   :nosignatures:

   try_import
   has_method
   is_seq_of
   is_list_of
   is_tuple_of
   is_filepath
